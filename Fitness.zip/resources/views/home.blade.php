@extends('layout')
@section('title', 'Beranda')
@section('content')
<div class="row justify-content-center">
    <img src="/bg-home.jpeg" alt="" class="w-100">
    <div class="text-light position-absolute mt-5 h1" style="top:10;font-size:64pt">Selamat Datang...</div>
</div>
@endsection
