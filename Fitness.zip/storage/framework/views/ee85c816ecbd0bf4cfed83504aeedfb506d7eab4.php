<?php $__env->startSection('title', 'Beranda'); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <img src="/bg-home.jpeg" alt="" class="w-100">
    <div class="text-light position-absolute mt-5 h1" style="top:10;font-size:64pt">Selamat Datang...</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/fitness/resources/views/home.blade.php ENDPATH**/ ?>