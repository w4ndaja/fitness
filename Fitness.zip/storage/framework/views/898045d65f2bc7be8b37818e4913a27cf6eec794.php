<?php $__env->startSection('title', 'Absensi'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-3">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-secondary d-flex justify-content-between flex-wrap">
                    <span class="text-light h2">Absensi</span>
                    <div class="d-flex flex-wrap justify-content-end">
                        <form action="<?php echo e(route('absensi.index')); ?>" class="d-flex flex-wrap">
                            <div class="form-group m-1 text-nowrap d-flex ">
                                <label class="mx-1 text-white">Tanggal : </label>
                                <input type="date" class="form-control" name="tanggal" value="<?php echo e(request('tanggal') ?? now()->format('Y-m-d')); ?>">
                            </div>
                            <div class="form-group m-1 d-flex">
                                <input type="text" class="form-control" placeholder="Cari..." name="query" value="<?php echo e(request('query')); ?>">
                                <button class="btn btn-info ml-2" type="submit">Cari</button>
                            </div>
                        </form>

                    </div>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('absensi.update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex justify-content-end">
                            <div class="form-group m-1 ml-3">
                                <button type="submit" class="btn btn-info">Simpan</button>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-stripped text-nowrap position-static">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Alamat</th>
                                        <th>Tanggal</th>
                                        <th>Jam Masuk</th>
                                        <th>Jam Keluar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pengunjungs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyP => $pengunjung): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($pengunjung->absensi->count() > 0): ?>
                                    <?php $__currentLoopData = $pengunjung->absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($pengunjung->nama); ?></td>
                                        <td><?php echo e($pengunjung->alamat); ?></td>
                                        <td><?php echo e($absensi->tanggal ?? request('tanggal')); ?><input type="hidden" name="pengunjung[<?php echo e($pengunjung->id); ?>][<?php echo e($absensi->id); ?>][tanggal]" value="<?php echo e($absensi->tanggal ?? request('tanggal')); ?>"></td>
                                        <td><input type="time" name="pengunjung[<?php echo e($pengunjung->id); ?>][<?php echo e($absensi->id); ?>][jam_masuk]" class="form-control" value="<?php echo e($absensi->jam_masuk); ?>"></td>
                                        <td><input type="time" name="pengunjung[<?php echo e($pengunjung->id); ?>][<?php echo e($absensi->id); ?>][jam_keluar]" class="form-control" value="<?php echo e($absensi->jam_keluar); ?>" <?php echo e($absensi->jam_masuk ? '' : 'disabled'); ?>></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td><?php echo e($pengunjung->nama); ?></td>
                                        <td><?php echo e($pengunjung->alamat); ?></td>
                                        <td>
                                            <?php echo e($pengunjung->absensi()->firstOrNew()->tanggal ?? (request('tanggal') ?? now()->format('Y-m-d'))); ?>

                                            <input type="hidden" name="pengunjung[<?php echo e($pengunjung->id); ?>][0][tanggal]" value="<?php echo e($absensi->tanggal ?? (request('tanggal') ?? now()->format('Y-m-d'))); ?>">
                                        </td>
                                        <td><input type="time" name="pengunjung[<?php echo e($pengunjung->id); ?>][0][jam_masuk]" class="form-control" value="<?php echo e($pengunjung->absensi()->firstOrNew()->jam_masuk); ?>"></td>
                                        <td><input type="time" name="pengunjung[<?php echo e($pengunjung->id); ?>][0][jam_keluar]" class="form-control" value="<?php echo e($pengunjung->absensi()->firstOrNew()->jam_keluar); ?>" <?php echo e($pengunjung->absensi()->firstOrNew()->jam_masuk ? '' : 'disabled'); ?>></td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </form>
                </div>
                <div class="card-footer">
                    
                    <?php echo e($pengunjungs->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/fitness/resources/views/absensi/index.blade.php ENDPATH**/ ?>