<?php $__env->startSection('title', 'Instruktur'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-3">
    <div class="row">
        <div class="col-md-12">
            <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert" id="success-alert">
                <h4 class="alert-heading h5">Berhasil!</h4>
                <p><?php echo e(session('success')); ?></p>
            </div>
            <script>
                setTimeout(function(){
                    document.getElementById('success-alert').remove()
                }, 2000);
            </script>
            <?php endif; ?>
            <div class="card">
                <div class="card-header bg-secondary d-flex justify-content-between">
                    <span class="text-light h2">Instruktur</span>
                    <div class="d-flex flex-wrap justify-content-end">
                        <form action="<?php echo e(route('instruktur.index')); ?>">
                            <div class="form-group m-1 d-flex">
                                <input type="text" class="form-control mr-2" placeholder="Cari..." name="query">
                                <button class="btn btn-icon btn-info" type="submit">Cari</button>
                            </div>
                        </form>
                        <div class="form-group m-1">
                            <a href="<?php echo e(route('instruktur.create')); ?>" class="btn btn-success">Tambah</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-stripped text-nowrap position-static">
                            <thead>
                                <tr>
                                    <th>Hari</th>
                                    <th>Nama</th>
                                    <th>Alamat</th>
                                    <th>Jenis Kelamin</th>
                                    <th>Member</th>
                                    <th class="position-sticky bg-light" style="right:0">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($instrukturs->count() < 1): ?> <tr>
                                    <td colspan="9999">
                                        <h3 class="text-center">Data Kosong...</h3>
                                    </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $instrukturs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $instruktur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($instruktur->hari); ?></td>
                                        <td><?php echo e($instruktur->nama); ?></td>
                                        <td><?php echo e($instruktur->alamat); ?></td>
                                        <td><?php echo e($instruktur->jenis_kelamin); ?></td>
                                        <td><?php echo e($instruktur->pengunjung->nama); ?></td>
                                        <td class="position-sticky bg-light dropleft" style="right:0">
                                            <a class="btn bg-white btn-sm shadow-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink_<?php echo e($i); ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Pilih
                                            </a>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink_<?php echo e($i); ?>">
                                                <a href="<?php echo e(route('instruktur.edit', $instruktur->id)); ?>" class="dropdown-item text-info">Edit</a>
                                                <a href="<?php echo e(route('instruktur.confirm-delete', $instruktur->id)); ?>" class="dropdown-item text-warning">Hapus</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <?php echo e($instrukturs->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/fitness/resources/views/instruktur/index.blade.php ENDPATH**/ ?>