<?php $__env->startSection('title', 'Tambah Transaksi Baru'); ?>
<?php $__env->startSection('content'); ?>
<div class="container pt-3 d-flex flex-column align-items-center">
    <div class="col-lg-8">
        <div class="card">
            <form action="<?php echo e(route('transaksi.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card-header bg-secondary d-flex justify-content-between">
                    <span class="text-light h2">Form Transaksi Baru</span>
                    <a href="<?php echo e(route('transaksi.index')); ?>" class="btn btn-info">Kembali</a>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label class="col-md-4">KODE TRANSAKSI</label>
                        <div class="col-md-8 d-flex align-items-center">
                            <input type="text" name="code_transaksi" class="form-control text-right <?php $__errorArgs = ['code_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['code_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <span class="border rounded"><?php echo e(now()->format('dmYhis')); ?></span>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-success" type="submit">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/fitness/resources/views/transaksi/create.blade.php ENDPATH**/ ?>