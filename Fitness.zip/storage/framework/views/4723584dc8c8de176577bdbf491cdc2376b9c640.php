<?php $__env->startSection('title', 'Edit Instruktur'); ?>
<?php $__env->startSection('content'); ?>
<div class="container pt-3 d-flex flex-column align-items-center">
    <div class="col-lg-8">
        <div class="card">
            <form action="<?php echo e(route('instruktur.update', $instruktur->id)); ?>" method="post">
                <?php echo method_field('patch'); ?>
                <?php echo csrf_field(); ?>
                <div class="card-header bg-secondary d-flex justify-content-between">
                    <span class="text-light h2">Form Edit Instruktur <?php echo e($instruktur->nama); ?></span>
                    <a href="<?php echo e(route('instruktur.index')); ?>" class="btn btn-info">Kembali</a>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label class="col-md-4">Nama</label>
                        <div class="col-md-8">
                            <input type="text" name="nama" value="<?php echo e($instruktur->nama); ?>" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-4">Jenis Kelamin</label>
                        <div class="col-md-8">
                            <select name="jenis_kelamin" value="<?php echo e($instruktur->jenis_kelamin); ?>" class="form-control <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option disabled selected>--Pilih Jenis Kelamin--</option>
                                <option <?php echo e($instruktur->jenis_kelamin == 'Pria' ? 'selected' : ''); ?>>Pria</option>
                                <option <?php echo e($instruktur->jenis_kelamin == 'Wanita' ? 'selected' : ''); ?>>Wanita</option>
                            </select>
                            <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-4">Hari</label>
                        <div class="col-md-8">
                            <select name="hari" value="<?php echo e($instruktur->hari); ?>" class="form-control <?php $__errorArgs = ['hari'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option <?php echo e($instruktur->hari == 'senin' ? 'selected' : ''); ?> value="senin">Senin</option>
                                <option <?php echo e($instruktur->hari == 'selasa' ? 'selected' : ''); ?> value="selasa">Selasa</option>
                                <option <?php echo e($instruktur->hari == 'rabu' ? 'selected' : ''); ?> value="rabu">Rabu</option>
                                <option <?php echo e($instruktur->hari == 'kamis' ? 'selected' : ''); ?> value="kamis">Kamis</option>
                                <option <?php echo e($instruktur->hari == 'jumat' ? 'selected' : ''); ?> value="jumat">Jumat</option>
                                <option <?php echo e($instruktur->hari == 'sabtu' ? 'selected' : ''); ?> value="sabtu">Sabtu</option>
                                <option <?php echo e($instruktur->hari == 'minggu' ? 'selected' : ''); ?> value="minggu">Minggu</option>
                            </select>
                            <?php $__errorArgs = ['hari'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-4">Alamat</label>
                        <div class="col-md-8">
                            <textarea name="alamat" value="<?php echo e($instruktur->alamat); ?>" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e($instruktur->alamat); ?></textarea>
                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-4">Member</label>
                        <div class="col-md-8">
                            <select name="pengunjung_id" value="<?php echo e($instruktur->pengunjung_id); ?>" class="form-control">
                                <?php $__currentLoopData = $pengunjungs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengunjungs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pengunjungs->id); ?>" <?php echo e($pengunjungs->id == $instruktur->pengunjung_id ? 'selected' : ''); ?>><?php echo e($pengunjungs->nama); ?> - <?php echo e($pengunjungs->alamat); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-success" type="submit">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/fitness/resources/views/instruktur/edit.blade.php ENDPATH**/ ?>