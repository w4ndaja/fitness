<?php $__env->startSection('title', 'Konfirmasi Hapus'); ?>
<?php $__env->startSection('content'); ?>
<div class="container pt-3">
    <div class="row d-flex justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">Peringatan...!</div>
                <div class="card-body">
                    Apakah Anda yakin ingin menghapus pengunjung dengan nama <?php echo e($pengunjung->nama); ?> ?
                </div>
                <div class="card-footer d-flex justify-content-between">
                    <a href="<?php echo e(route('pendaftaran.index')); ?>" class="btn btn-info">Kembali</a>
                    <form action="<?php echo e(route('pendaftaran.destroy', $pengunjung->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/fitness/resources/views/pendaftaran/confirm-delete.blade.php ENDPATH**/ ?>