@extends('layout')
@section('title', 'Beranda')
@section('content')
    <div class="container py-5">
        <div class="alert alert-info">Selamat Datang...</div>
    </div>
@endsection
