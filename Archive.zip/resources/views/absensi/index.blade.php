@extends('layout')
@section('title', 'Absensi')
@section('content')
<div class="container py-3">
    <div class="row">
        <div class="col-md-12">
            @if(session('success'))
            <div class="alert alert-success" role="alert" id="success-alert">
                <h4 class="alert-heading h5">Berhasil!</h4>
                <p>{{session('success')}}</p>
            </div>
            <script>
                setTimeout(function(){
                    document.getElementById('success-alert').remove()
                }, 2000);
            </script>
            @endif
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <span class="text-info">Absensi</span>
                    <div class="d-flex flex-wrap justify-content-end">
                        <div class="form-group m-1 text-nowrap d-flex ">
                            <label>Tanggal : </label>
                            <select name="tanggal" class="form-control ml-2">
                                <option value="Sekarang">Sekarang</option>
                                <option value="besok">Semalam</option>
                            </select>
                        </div>
                        <div class="form-group m-1">
                            <input type="text" class="form-control" placeholder="Cari...">
                        </div>
                        <div class="form-group m-1">
                            <a href="{{route('pendaftaran.create')}}" class="btn btn-success">Tambah</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-stripped text-nowrap position-static">
                            <thead>
                                <tr>
                                    <th>Nama</th>
                                    <th>Jam Masuk</th>
                                    <th>Jam Keluar</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if($absensis->count() < 1) <tr>
                                    <td colspan="9999">
                                        <h3 class="text-center">Data Kosong...</h3>
                                    </td>
                                    </tr>
                                    @endif
                                    @foreach ($absensis as $i => $absensi)
                                    <tr>
                                        <td>{{$absensi->nama}}</td>
                                        <td>{{$absensi->tempat_lahir}}</td>
                                        <td>{{$absensi->tanggal_lahir}}</td>
                                        <td>{{$absensi->alamat}}</td>
                                        <td>{{$absensi->jenis_kelamin}}</td>
                                        <td class="text-center">@if($absensi->member) <span class="text-light bg-success p-1 rounded shadow-sm text-nowrap">Member</span> @else <span class="text-muted text-nowrap">Bukan Member</span> @endif</td>
                                        <td>@if($absensi->member) <span class="text-light bg-info p-1 rounded shadow-sm text-nowrap">{{$absensi->member->created_at->diffForHumans()}}</span> @else <span class="text-muted">--</span> @endif</td>
                                        <td class="text-center">@if($absensi->member) <span class="text-light bg-info p-1 rounded shadow-sm text-wrap">{{$absensi->member->berakhir_pada->format('d M Y')}}</span> <span class="text-dark">{{$absensi->member->berakhir_pada->diffForHumans()}}</span> @else <span class="text-muted">--</span> @endif</td>
                                        <td class="position-sticky bg-light dropleft" style="right:0">
                                            <a class="btn bg-white btn-sm shadow-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink_{{$i}}" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Pilih
                                            </a>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink_{{$i}}">
                                                <a href="{{route('pendaftaran.edit', $absensi->id)}}" class="dropdown-item text-info">Edit</a>
                                                @if($absensi->member) <a href="{{route('pendaftaran.confirm-delete-member', $absensi->id)}}" class="dropdown-item text-danger">Batalkan Member</a> @else
                                                <a href="{{route('pendaftaran.confirm-member', $absensi->id)}}" class="dropdown-item text-success">Jadikan Member</a> @endif
                                                <a href="{{route('pendaftaran.confirm-delete', $absensi->id)}}" class="dropdown-item text-warning">Hapus</a>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    {{$absensis->links()}}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
