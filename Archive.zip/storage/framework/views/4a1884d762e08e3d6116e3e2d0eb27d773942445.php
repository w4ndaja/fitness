<?php $__env->startSection('title', 'Konfirmasi Hapus Member'); ?>
<?php $__env->startSection('content'); ?>
<div class="container pt-3">
    <div class="row d-flex justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">Peringatan...!</div>
                <div class="card-body">
                    Apakah Anda yakin ingin <span class="text-danger">mengapus status member</span>  pada pengunjung dengan nama <strong class="text-info"><?php echo e($pengunjung->nama); ?></strong> ?
                </div>
                <div class="card-footer d-flex justify-content-between">
                    <a href="<?php echo e(route('pendaftaran.index')); ?>" class="btn btn-info">Kembali</a>
                    <form action="<?php echo e(route('pendaftaran.remove-from-member', $pengunjung->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">Hapus Member</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/fitness/resources/views/pendaftaran/confirm-delete-member.blade.php ENDPATH**/ ?>