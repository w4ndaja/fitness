<?php $__env->startSection('title', 'Beranda'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <div class="alert alert-info">Selamat Datang...</div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/fitness/resources/views/home.blade.php ENDPATH**/ ?>