<?php $__env->startSection('title', 'Absensi'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-3">
    <div class="row">
        <div class="col-md-12">
            <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert" id="success-alert">
                <h4 class="alert-heading h5">Berhasil!</h4>
                <p><?php echo e(session('success')); ?></p>
            </div>
            <script>
                setTimeout(function(){
                    document.getElementById('success-alert').remove()
                }, 2000);
            </script>
            <?php endif; ?>
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <span class="text-info">Absensi</span>
                    <div class="d-flex flex-wrap justify-content-end">
                        <div class="form-group m-1 text-nowrap d-flex ">
                            <label>Tanggal : </label>
                            <select name="tanggal" class="form-control ml-2">
                                <option value="Sekarang">Sekarang</option>
                                <option value="besok">Semalam</option>
                            </select>
                        </div>
                        <div class="form-group m-1">
                            <input type="text" class="form-control" placeholder="Cari...">
                        </div>
                        <div class="form-group m-1">
                            <a href="<?php echo e(route('pendaftaran.create')); ?>" class="btn btn-success">Tambah</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-stripped text-nowrap position-static">
                            <thead>
                                <tr>
                                    <th>Nama</th>
                                    <th>Jam Masuk</th>
                                    <th>Jam Keluar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($absensis->count() < 1): ?> <tr>
                                    <td colspan="9999">
                                        <h3 class="text-center">Data Kosong...</h3>
                                    </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $absensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $absensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($absensi->nama); ?></td>
                                        <td><?php echo e($absensi->tempat_lahir); ?></td>
                                        <td><?php echo e($absensi->tanggal_lahir); ?></td>
                                        <td><?php echo e($absensi->alamat); ?></td>
                                        <td><?php echo e($absensi->jenis_kelamin); ?></td>
                                        <td class="text-center"><?php if($absensi->member): ?> <span class="text-light bg-success p-1 rounded shadow-sm text-nowrap">Member</span> <?php else: ?> <span class="text-muted text-nowrap">Bukan Member</span> <?php endif; ?></td>
                                        <td><?php if($absensi->member): ?> <span class="text-light bg-info p-1 rounded shadow-sm text-nowrap"><?php echo e($absensi->member->created_at->diffForHumans()); ?></span> <?php else: ?> <span class="text-muted">--</span> <?php endif; ?></td>
                                        <td class="text-center"><?php if($absensi->member): ?> <span class="text-light bg-info p-1 rounded shadow-sm text-wrap"><?php echo e($absensi->member->berakhir_pada->format('d M Y')); ?></span> <span class="text-dark"><?php echo e($absensi->member->berakhir_pada->diffForHumans()); ?></span> <?php else: ?> <span class="text-muted">--</span> <?php endif; ?></td>
                                        <td class="position-sticky bg-light dropleft" style="right:0">
                                            <a class="btn bg-white btn-sm shadow-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink_<?php echo e($i); ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Pilih
                                            </a>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink_<?php echo e($i); ?>">
                                                <a href="<?php echo e(route('pendaftaran.edit', $absensi->id)); ?>" class="dropdown-item text-info">Edit</a>
                                                <?php if($absensi->member): ?> <a href="<?php echo e(route('pendaftaran.confirm-delete-member', $absensi->id)); ?>" class="dropdown-item text-danger">Batalkan Member</a> <?php else: ?>
                                                <a href="<?php echo e(route('pendaftaran.confirm-member', $absensi->id)); ?>" class="dropdown-item text-success">Jadikan Member</a> <?php endif; ?>
                                                <a href="<?php echo e(route('pendaftaran.confirm-delete', $absensi->id)); ?>" class="dropdown-item text-warning">Hapus</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <?php echo e($absensis->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/fitness/resources/views/absensi/index.blade.php ENDPATH**/ ?>