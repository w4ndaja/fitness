<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
})->name('home');
Route::middleware('auth')->group(function(){
	Route::resource('absensi', App\Http\Controllers\AbsensiController::class);
	Route::resource('pendaftaran', App\Http\Controllers\PendaftaranController::class);
	Route::get('pendaftaran/confirm-delete/{pengunjung}', [App\Http\Controllers\PendaftaranController::class, 'confirmDelete'])->name('pendaftaran.confirm-delete');
	Route::get('pendaftaran/confirm-member/{pengunjung}', [App\Http\Controllers\PendaftaranController::class, 'confirmMember'])->name('pendaftaran.confirm-member');
	Route::post('pendaftaran/add-to-member/{pengunjung}', [App\Http\Controllers\PendaftaranController::class, 'addToMember'])->name('pendaftaran.add-to-member');
	Route::post('pendaftaran/remove-from-member/{pengunjung}', [App\Http\Controllers\PendaftaranController::class, 'removeFromMember'])->name('pendaftaran.remove-from-member');
	Route::get('pendaftaran/confirm-delete-member/{pengunjung}', [App\Http\Controllers\PendaftaranController::class, 'confirmDeleteMember'])->name('pendaftaran.confirm-delete-member');
	Route::resource('member', App\Http\Controllers\MemberController::class);
	Route::resource('transaksi', App\Http\Controllers\TransaksiController::class);
	Route::resource('instruktur', App\Http\Controllers\InstrukturController::class);
	Route::resource('laporan', App\Http\Controllers\LaporanController::class);
});

Route::get('login', [App\Http\Controllers\AuthController::class, 'login'])->name('login');
Route::post('login', [App\Http\Controllers\AuthController::class, 'authenticate'])->name('login');
Route::post('logout', [App\Http\Controllers\AuthController::class, 'logout'])->name('logout');
