<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    use HasFactory;
    public $table='member';
    protected $guarded = [];
    protected $casts =[
        'created_at' => 'datetime:d M Y',
        'berakhir_pada' => 'datetime:d M Y',
    ];

    public function instruktur(){
    	return $this->belongsTo(App\Models\Instruktur::class, 'member_id');
    }

}
